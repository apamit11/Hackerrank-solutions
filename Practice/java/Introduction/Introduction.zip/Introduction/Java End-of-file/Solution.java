import java.io.*;
import java.util.*;

public class Solution {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int x=1;
        for(x=1;sc.hasNext()==true;x++)
        System.out.println(x+" "+sc.nextLine());
    }
}