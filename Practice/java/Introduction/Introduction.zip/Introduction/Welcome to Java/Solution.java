public class Solution {
   
   public static void main(String []argv)
   {
      System.out.println("Hello World.");//Write your solution here.
      System.out.println("Hello Java.");
   }

}
